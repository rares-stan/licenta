app.directive("kanbanTracks", function() {
	return {
		restrict: "E",
		replace: true,
		scope: "=",
		templateUrl: "templates/KanbanTracks.html",
		link: function($scope, element, attr) {
			/*console.log("kanban tracks");
			console.log($scope);*/
		}
	};
});